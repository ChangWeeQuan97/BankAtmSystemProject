﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BankAtmSystem
{
    class other_method
    {
        public static void Thank_you()
        {
            Console.Write("Hope you enjoy our service, ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Thank You !\n");
            Console.ResetColor();
            PrintforUser();
        }
        public static void PrintforUser()
        {
            Console.Write("Press Y or any key to continue");
            Console.ReadKey();
            Console.Clear();
        }
        public static void Min_amount(string s)
        {
            Console.WriteLine($"\nMinimum {s} amount is RM10. ");
            PrintforUser();
        }
        public static void AfterProcess_withdraw()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nProcessing Successful");
            Thread.Sleep(1000);
            Console.ResetColor();
            Console.WriteLine("Please take your cash. ");
        }
        public static void AfterProcess_fastwithdraw()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Processing Successful");
            Thread.Sleep(1000);
            Console.ResetColor();
            Console.WriteLine("Please take your cash. ");
        }
        public static void AfterProcess()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nProcessing Successful");
            Thread.Sleep(1000);
            Console.ResetColor();
        }
        public static void yes_no(string s)
        {
            Console.WriteLine(s);
            Console.WriteLine("1. Yes\t2. No");
            Console.Write("Enter Your Option: ");
        }
        public static void Print_Receipt()
        {
            Console.Clear();
            Console.WriteLine("Your receipt is printing succesfully, please take your receipt. ");
            PrintforUser();
        }
        public static void yellow_head(string s, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
            Console.WriteLine(s);
            Console.WriteLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
            Console.ResetColor();
        }
        public static void yellow_text(string s, string t)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
            Console.WriteLine(s);
            Console.WriteLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
            Console.ResetColor();
            Console.WriteLine(t);
        }
        public static void color_text(string s, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(s);
            Console.ResetColor();
            PrintforUser();
        }
        public static void Fast_Cash()
        {
            yellow_head("                 Fast Cash Withdrawal ", ConsoleColor.Yellow);
            Console.WriteLine("1. RM100 \t 5.RM1000");
            Console.WriteLine("2. RM200 \t 6.RM2000 ");
            Console.WriteLine("3. RM300 \t 7.RM5000 ");
            Console.WriteLine("4. RM500 \t 8. Back ");
            Console.Write("Enter Your Option:");
        }
        public static void for_each(User p, List<User> listofuser, string cardno, string pinno)
        {
            foreach (var list in listofuser)
            {
                if (cardno == list.card_no && pinno != list.pin_no)
                {
                    p = list;
                }
            }
            p.Login_Attempt--;
            if (p.Login_Attempt == 0)
            {
                Console.WriteLine($"\nInvalid Card No or Pin No.");
                color_text("Login failure, Your account has been locked. ", ConsoleColor.Red);
            }
            else
            {
                Console.WriteLine($"\nInvalid Card No or Pin No.");
                color_text($"Login unsuccessful, attempt available: {p.Login_Attempt}", ConsoleColor.Red);
            }
        }
    }
}
